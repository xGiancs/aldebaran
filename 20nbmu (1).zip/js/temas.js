const $pDom = document.getElementById("dom");

$pDom.innerHTML = "Mantengamos tradiciones";

$pDom.style.fontSize = "100%";
$pDom.style.backgroundColor = "grey";
$pDom.style.padding = ".5rem";
$pDom.style.borderradius = ".5rem;";
$pDom.style.color = "white";
$pDom.style.textAlign = "center";

const $btnTemaClaro = document.getElementById("btn-tema-claro");

$btnTemaClaro.addEventListener("click", (e) => {
  document.getElementById("tema").href = "css/estilos.css";
});

const $btnTemaObscuro = document.getElementById("btn-tema-obscuro");

$btnTemaObscuro.addEventListener("click", (e) => {
  document.getElementById("tema").href = "css/obscuro.css";
});

function saludar(e) {
  alert("No olvides seguirnnos en redes sociales!");
  console.log(e);
  e.target.style.backgroundColor = "rgb(48, 84, 148)";
  e.target.style.color = "white";
  e.target.innerText = "PRESIONAME";
}

const $btn = document.getElementById("presioname");

$btn.addEventListener("click", saludar);
